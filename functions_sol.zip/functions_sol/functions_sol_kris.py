def get_factorial(n):
    factorial = 1
    for i in range (n,1,-1):
        factorial *= i
    return factorial

def get_multiples(n=5, divisor=2):
    pass


def is_prime(n):
    """Write a function that determines whether or not an inputted number is prime, and then prints
    The number you inputted is a prime/ not a prime number.' depending on what your script finds
    (note that this means putting a print in front of the function when testing it will be redundant for this case).


    Return True if the input is prime, False otherwise
    Parameters
    ----------
    n: {int} input integer

    Returns
    -------
    is_prime: {bool} whether n is prime
    """

    divisor = 2
    result = True
    while divisor < n:
        if n % divisor == 0:
            result = False
            break
        divisor += 1
    return result



def get_all_primes(n):
    """Write a function that returns all the prime numbers up to an inputted
    number (Hint: It might be helpful to use/modify the prime function you wrote earlier).
    prime number is divisible by 1 and self only
    """
    primes_list = []

    p_number = 1

    while p_number <= n:
        #print(p_number)
        if is_prime(p_number):
            primes_list.append(p_number)
        p_number+=1
    return primes_list

def count_words(t):
    """Write a function that counts the number of words in an inputted string, 
    where we consider words to be separated by spaces."""

    wordlist = list(n for n in t.split())
    return len(wordlist)

def count_words_w_delim(t,d=' '):
    """Write a function that counts the number of words in an inputted string,
    where we consider words to be separated by spaces."""

    wordlist = list(n for n in t.split(d))
    return len(wordlist)


def get_divisibles_for_list(l,n):
    return_list = []
    input_list = [int(s) for s in l.split(',')]
    #return_list.add('yes') if n % match_candidate ==0 else return_list.add('no') for match_candidate in input_list
    for each_number in input_list:
        if each_number % int(n) == 0:
            return_list.append('yes')
        else:
            return_list.append('no')
    return return_list

def get_words_with_this_letter(text, letter):
    return_list = []
    input_list = [s for s in text.split()]
    #print(input_list)
    for each_word in input_list:
        if letter.lower() in each_word.lower():
            return_list.append(each_word)
        else:
            pass
    return return_list


def get_words_index_for_this_substring(text, subs):
    return_list = []
    input_list = [s for s in text.split()]
    #print(input_list)
    for idx,each_word in enumerate(input_list):
        if subs.lower() in each_word.lower():
            return_list.append(idx)
        else:
            pass
    return return_list





def get_word_lenghts(t,d=' '):
    """Write a function that takes in a string, and returns a list that holds the length of
    each word in the phrase, separated by an inputted delimiter (so you're function should accept two arguments again).
    Make a space the default delimiter like you did in 2. For example, if the arguments to your function were
    This is a test string (and nothing else), your function should return [4, 2, 1, 4, 6].
    Go ahead and don't worry about removing punctuation
    (you can include it in the word length - e.g. "this." has five letters, if we count the period"""

    wordlist = list(n for n in t.split(d))
    char_counts = []
    for word in wordlist:
        char_counts.append(len(word))

    return (char_counts)

#print(get_factorial(5))
#print(is_prime(7))
#print(count_words(input("enter text")))
#print(count_words_w_delim(input("enter text"),int(input("enter delimiter"))))
#print(get_word_lenghts(input("enter text"),";"))
#print(get_all_primes(35))
#print(get_divisibles_for_list(input("enter divisible numbers sep by commas"),input("enter test divisor")))
#print(get_words_with_this_letter(input("enter words"), input("enter letter")))
#print(get_words_index_for_this_substring(input("enter words"), input("enter substring")))