#The one line solution for #7
def contains(inlist=['I','am'], str1='m'):
   return [idx for idx, x in enumerate(inlist) if x.strip().lower().find(str1.lower())>-1]

print(contains(['This', 'is', 'an' , 'example'],'is'))