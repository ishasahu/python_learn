def factorial(n):
   num = 1
   for i in range(1,n+1):
       num *= i
   return num

def is_prime_number(n):
   for i in range(2,n):
       if n % i == 0:
           return [n, False, 'The number you inputted is not a prime']

   return [n, True, 'The number you inputted is a prime']

def word_count(word, delimiter = ' '):
   return len(word.split(delimiter))

def all_primes(n):
   my_primes = []
   for i in range(1,n+1):
       if is_prime_number(i)[1]==True:
           my_primes.append(str(i))

   return ' '.join(my_primes)

def is_multiples(num_list, divisor):
   my_multiples = ['yes' if n % divisor == 0 else 'no' for n in num_list]
   return my_multiples

def string_word_search(word_list, search_string, is_indice_return = False)
   my_search = [s if is_indice_return == False else word_list.index(s) for s in word_list if search_string in s]
   return my_search




#print(factorial(10))
#print((is_prime_number(101)[2]))
#print((is_prime_number(101)))
#print(word_count('hi there how are you today'))
#print(word_count('hi|there| how |are| you| today','|'))
#print(all_primes(100))
#print(is_multiples([2,4,6,8,10],3))
#print(string_word_search(['I', 'am', 'in', 'love', 'with', 'Python'],'n',False))
#print(string_word_search(['This', 'is', 'an' , 'example'],'is',True))