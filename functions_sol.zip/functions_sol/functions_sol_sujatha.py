def calc_factorial(n):
   if n==0:
       return 1
   else:
       return n*calc_factorial(n-1)
lst= input("Enter list of Strings:").split(',')
d=input("Enter the ending char:")

def substr_idx(lst,d):
     out_list=[i for i in range(len(lst)) if lst[i].find(d)!=-1]
     return out_list
substr_idx(lst,d)